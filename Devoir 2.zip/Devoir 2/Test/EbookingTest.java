import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import ebook.controller.EbookingControl;
import ebook.controller.IEbookingReaction;
import ebook.controller.EbookingControl.Status;

public class EbookingTest {

    private EbookingControl ebooking;

    @Before
    public void setUp() {
        // Initialisation avec une réaction factice pour simuler le système
        ebooking = new EbookingControl(new DummyReaction());
    }

    @Test
    public void testReservationNoBaggageFlow() throws Exception {
        // L'utilisateur commence à l'état initial
        assertEquals(Status.IDLE, ebooking.getCurrent());

        // Entrée du numéro de réservation
        ebooking.reservationNumber();
        assertEquals(Status.LOOKINGUPRESERVATION, ebooking.getCurrent());

        // Réservation trouvée
        ebooking.found();
        assertEquals(Status.DISPLAYINGFLIGHT, ebooking.getCurrent());

        // Confirmation sans bagages
        ebooking.confirm();
        assertEquals(Status.WAITFORRESPONSE, ebooking.getCurrent());

        ebooking.no(); // aucun bagage
        assertEquals(Status.WAITFORDOCUMENTSWITHRAWAL, ebooking.getCurrent());

        // Retrait des documents
        ebooking.withdrawDocuments();
        assertEquals(Status.IDLE, ebooking.getCurrent());
    }

    @Test
    public void testReservationWithBaggageFlow() throws Exception {
        ebooking.reservationNumber();
        ebooking.found();
        ebooking.confirm();
        ebooking.yes(); // avec bagages
        assertEquals(Status.WAITFORBAGGAGENUMBERS, ebooking.getCurrent());

        ebooking.numberOfPieces();
        assertEquals(Status.WAITFORDOCUMENTSWITHRAWAL, ebooking.getCurrent());

        ebooking.withdrawDocuments();
        assertEquals(Status.IDLE, ebooking.getCurrent());
    }

    @Test
    public void testReservationNotFound() throws Exception {
        // Cas où la réservation est introuvable
        ebooking.reservationNumber();
        ebooking.notFound();
        assertEquals(Status.IDLE, ebooking.getCurrent());
    }

    @Test
    public void testTimeoutAndWithdraw() throws Exception {
        ebooking.reservationNumber();
        ebooking.found();
        ebooking.confirm();
        ebooking.no(); // aller à WAITFORDOCUMENTSWITHRAWAL

        // Simulation d’un timeout (inactivité)
        ebooking.timeout();
        assertEquals(Status.SOUNDINGALARM, ebooking.getCurrent());

        // Retrait des documents après l’alarme
        ebooking.withdrawDocuments();
        assertEquals(Status.IDLE, ebooking.getCurrent());
    }

    @Test
    public void testCancelMidProcess() throws Exception {
    ebooking.reservationNumber();
    ebooking.found();
    ebooking.confirm();
    ebooking.cancel(); // test de retour volontaire à IDLE
    assertEquals(Status.IDLE, ebooking.getCurrent());
    }


    // Classe factice pour simuler les réactions du système (inutile de les implémenter ici)
    static class DummyReaction implements IEbookingReaction {
        public void lookupReservation() {}
        public void displayFlight() {}
        public void errorMessage() {}
        public void askForReservationNumber() {}
        public void askForBaggages() {}
        public void displayReservationDetails() {}
        public void askCustomerWishToChange() {}
        public void printBoardingPass() {}
        public void ejectBoardingPass() {}
        public void askForNumberOfPieces() {}
        public void printBaggageSlips() {}
        public void ejectBaggageSlips() {}
        public void displayProceedsToAgentMessage() {}
        public void startAlarm() {}
        public void stopAlarm() {}
    }
}
